<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1417809984982'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.installFolder' value='/usr/local/google/buildbot/repo_clients/https___android.googlesource.com_a_platform_manifest.git/studio-1.0-release/out/host/maven/bundles-24.0.0-SNAPSHOT/products/monitorproduct/linux/gtk/x86_64/monitor'/>
    <property name='org.eclipse.equinox.p2.cache' value='/usr/local/google/buildbot/repo_clients/https___android.googlesource.com_a_platform_manifest.git/studio-1.0-release/out/host/maven/bundles-24.0.0-SNAPSHOT/products/monitorproduct/linux/gtk/x86_64/monitor'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=en_US,osgi.ws=gtk,osgi.arch=x86_64,osgi.os=linux'/>
  </properties>
</profile>
